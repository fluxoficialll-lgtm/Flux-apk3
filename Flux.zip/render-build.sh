#!/usr/bin/env bash
# exit on error
set -o errexit

echo "--- 🚀 Iniciando Build do Flux Platform ---"

# 1. Instalar dependências (Backend e Frontend)
echo "--- 📦 Instalando dependências ---"
npm install

# 2. Limpar build anterior para evitar cache sujo
echo "--- 🧹 Limpando artefatos antigos ---"
rm -rf dist

# 3. Gerar o build do Frontend via Vite
# Isso criará a pasta /dist que o server.js utiliza
echo "--- 🏗️ Compilando o Frontend (Vite) ---"
npm run build

echo "--- ✅ Build concluído com sucesso! ---"